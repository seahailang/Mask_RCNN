#!/usr/bin/env python
# encoding: utf-8


"""
@version: 0.0
@author: hailang
@Email: seahailang@gmail.com
@software: PyCharm
@file: __main__.py
@time: 2018/4/2 16:06
"""

if __name__ == '__main__':
    pass